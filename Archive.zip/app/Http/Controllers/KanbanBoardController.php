<?php

namespace App\Http\Controllers;

class KanbanBoardController extends Controller
{
    public function index()
    {
        return view('index');
    }
}
